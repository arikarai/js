let email={
    sentTo:"hawa",
    sentFrom:"baka",
    myDetail:function(){
        console.log('msg sent');
    }
};
console.log(email);
email.myDetail();