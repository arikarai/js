//task2
let a=99;
a++;
console.log(a);
//task3
let r=100;
r--;
console.log(r);