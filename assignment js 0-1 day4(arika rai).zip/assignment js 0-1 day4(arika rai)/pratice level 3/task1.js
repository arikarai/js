var k=parseFloat("1");
var b=parseFloat("10.00098");
var c=parseFloat("9.0000");
var d=parseFloat("21 age");
var e=parseFloat("2 4 6");
var f=parseFloat("better now 10");
console.log(k);
console.log(b);
console.log(c);
console.log(d);
console.log(e);
console.log(f);
// pharse a string and return float number