var a='"programming is fun"';
console.log(a);