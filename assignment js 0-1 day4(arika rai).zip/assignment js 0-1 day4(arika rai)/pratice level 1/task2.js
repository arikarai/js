var myName="Arika";
var Roll_number=10;
var price=234.90;
