let a=prompt("enter your name");
let b=prompt("enter your surname");
console.log(a+b);
