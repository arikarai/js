console.error("error");
console.warn("this is it!!!");