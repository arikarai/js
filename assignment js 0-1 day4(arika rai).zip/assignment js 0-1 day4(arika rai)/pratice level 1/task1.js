let a;
a=10;
alert(a);
console.log(a);