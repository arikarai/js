const a=9;
const a=0;
 // already assigned value to variable a ,can't assign other value once declared constant
const b=0;