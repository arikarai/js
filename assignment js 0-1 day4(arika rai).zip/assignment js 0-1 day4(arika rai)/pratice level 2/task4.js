
let a=true,b=true;
console.log(a+b);