 let a=prompt("first digit");
 a=parseInt(a);
 let b=prompt("second digit");
 b=parseInt(b);
 let c=a+b;
 let d=a-b;
 console.log("the sum is"+" "+c);
 console.log("the difference is"+" "+d);
 console.log("the multiplication"+" "+a*b);
 console.log("the division is"+" "+a/b);

