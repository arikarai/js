var myCityName="kathmandu";
console.log(myCityName);

//task 2
var ProgrammingEngaging=true;
console.log(ProgrammingEngaging);

//task 3
let age=34;//int datatype
console.log(typeof age);
console.log(age);


//task4
var totalUsers;
console.log(totalUsers);

//task5
var phoneNo=9876757576;//longint datatype
console.log(phoneNo);
console.log(typeof phoneNo);

//task6
let laptop={
    name:"hp",
    price:"******",
    myDetail:function(){
        console.log('laptop detail');
    }
};
console.log(laptop);
laptop.myDetail();


//task7
let data={
    a:7,
    b:"k"
}
console.log(typeof (data));

//task8
let a=prompt("enter value");
console.log(a);
console.log(typeof(a));

//task9
const BG_COLOR="red"

//task 10
const a;
const a=0;
console.log(a);
